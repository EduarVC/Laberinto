
package com.mycompany.laberinto;

public class Reportes {
    public static void Reportes(){
        System.out.println("En proceso... ");
    }
}
